from dataclasses import dataclass

@dataclass(frozen=True)
class Transition:
    next_state: int
    reward: float
    done: bool

class Environment:
    """
    Simple 1D grid world with a single treasure.
    States are 0..size-1. Actions: 0=left, 1=right.
    Precomputes legal transitions for O(1) step time.
    """
    def __init__(self, size: int = 7, treasure: int | None = None) -> None:
        if size < 2:
            raise ValueError("size must be >= 2")
        self.size = size
        self.treasure = treasure if treasure is not None else (self.size - 1)
        if not (0 <= self.treasure < self.size):
            raise ValueError("treasure index out of bounds")
        self.state = 0
        self._precompute_transitions()

    def _precompute_transitions(self) -> None:
        # For each state, precompute the results of actions 0 and 1
        self._transitions: list[tuple[Transition, Transition]] = []
        for s in range(self.size):
            # action 0: left
            left_state = s - 1 if s > 0 else 0
            # action 1: right
            right_state = s + 1 if s < self.size - 1 else self.size - 1

            def build(ns: int) -> Transition:
                if ns == self.treasure:
                    return Transition(next_state=ns, reward=10.0, done=True)
                return Transition(next_state=ns, reward=-1.0, done=False)

            self._transitions.append((build(left_state), build(right_state)))

    def reset(self) -> int:
        self.state = 0
        return self.state

    def step(self, action: int) -> tuple[int, float, bool]:
        # O(1) transition lookup
        trans = self._transitions[self.state][action]
        self.state = trans.next_state
        return trans.next_state, trans.reward, trans.done

