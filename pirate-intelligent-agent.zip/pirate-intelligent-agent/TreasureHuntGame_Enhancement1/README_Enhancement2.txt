Enhancement Two – Algorithms and Data Structure
Artifact: TreasureHuntGame (Reinforcement Learning Project)

This milestone focuses on algorithmic efficiency and data-structure improvements.

Key Enhancements
----------------
1) Epsilon-Greedy Decay (ε):
   - Exploration probability decays each episode toward ε_min.
   - Encourages exploration early and exploitation later.

2) Adaptive Learning Rate (α):
   - α decays toward α_min to stabilize Q-updates over time.

3) Constant-Time Lookups & Precomputed Transitions:
   - Environment precomputes legal transitions for every state, allowing O(1) step() calls.

4) Vectorized Operations:
   - Q-table uses NumPy arrays; argmax and max are vectorized, keeping updates O(1) per step.

5) Early Stopping (Moving Average Reward):
   - Training halts when the moving average over the last N episodes meets a target threshold.

6) Input Validation & Reproducibility:
   - Validates hyperparameters and uses a fixed seed by default for deterministic runs.

Big-O Summary
-------------
- Per-step update: O(1)
- Per-episode runtime: O(T), where T is steps per episode
- Total training: O(E × T), where E is number of episodes
- Space: O(S × A) for the Q-table, with S states and A actions

How to Run
----------
1. Python 3.10+ with NumPy installed (pip install numpy)
2. Run:  python main.py
3. Observe progress logs and the final training summary.
