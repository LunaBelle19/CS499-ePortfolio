from __future__ import annotations

from typing import Optional, Callable
import numpy as np

from agent import Agent
from environment import Environment
from database_handler import save_run_summary   # NEW import


class GameController:
    """Coordinates training with early stopping, metrics, and database logging."""

    def __init__(
        self,
        episodes: int = 2000,
        max_steps_per_episode: int = 200,
        moving_avg_window: int = 100,
        target_avg_reward: float = 7.0,
        env_size: int = 7,
        seed: int | None = 42,
    ) -> None:
        self.env = Environment(size=env_size)
        self.agent = Agent(state_size=self.env.size, action_size=2, seed=seed)
        self.episodes = episodes
        self.max_steps = max_steps_per_episode
        self.window = moving_avg_window
        self.target = target_avg_reward

        self.episode_rewards: list[float] = []

    def train(self, progress_cb: Optional[Callable[[int, float], None]] = None) -> dict:
        """
        Train the agent using Q-learning.

        In addition to running the reinforcement-learning loop and supporting
        early stopping based on a moving average reward window, this method
        now also logs a summary of each full training run to the lightweight
        database layer in `database_handler.py`.
        """
        for ep in range(1, self.episodes + 1):
            state = self.env.reset()
            total_reward = 0.0

            for _ in range(self.max_steps):
                action = self.agent.choose_action(state)
                next_state, reward, done = self.env.step(action)
                self.agent.update_q(state, action, reward, next_state)
                state = next_state
                total_reward += reward
                if done:
                    break

            # schedules and metrics
            self.agent.end_episode()
            self.episode_rewards.append(total_reward)

            if progress_cb and ep % 50 == 0:
                progress_cb(ep, total_reward)

            # Early stopping on moving average reward plateau
            if len(self.episode_rewards) >= self.window:
                avg = float(np.mean(self.episode_rewards[-self.window:]))
                if progress_cb and ep % 50 == 0:
                    progress_cb(ep, avg)
                if avg >= self.target:
                    # Build summary dict and save it to the database
                    summary = {
                        "episodes_ran": ep,
                        "avg_reward_window": avg,
                        "stopped_early": True,
                    }
                    save_run_summary(summary)
                    return summary

        # If not early-stopped
        final_avg = float(np.mean(self.episode_rewards[-self.window:])) if self.episode_rewards else 0.0
        summary = {
            "episodes_ran": self.episodes,
            "avg_reward_window": final_avg,
            "stopped_early": False,
        }
        save_run_summary(summary)
        return summary

    def run_greedy_episode(self) -> list[int]:
        """
        Run one episode using a greedy policy (no exploration) after training.
        Returns the list of visited states so you can print the path.
        """
        # Temporarily force greedy behavior
        old_eps = self.agent.epsilon
        self.agent.epsilon = 0.0

        path: list[int] = []
        state = self.env.reset()
        path.append(state)

        for _ in range(self.max_steps):
            action = self.agent.choose_action(state)
            next_state, _, done = self.env.step(action)
            path.append(next_state)
            state = next_state
            if done:
                break

        # Restore epsilon
        self.agent.epsilon = old_eps
        return path
