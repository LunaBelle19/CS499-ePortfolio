"""
database_handler.py
--------------------
A lightweight simulated database layer for storing
training results, metrics, and run summaries for the 
TreasureHuntGame reinforcement-learning project.

This enhancement demonstrates database design, secure
data handling, error management, and persistent storage.
"""

import json
import os
import tempfile
from datetime import datetime

DB_FILE = "training_database.json"


def _safe_write(filepath: str, data: dict) -> None:
    """
    Safely writes JSON data to disk using an atomic write pattern.
    This prevents corrupt files if the write is interrupted.
    """
    try:
        # Write to a temporary file first
        temp_fd, temp_path = tempfile.mkstemp()
        with os.fdopen(temp_fd, "w", encoding="utf-8") as temp_file:
            json.dump(data, temp_file, indent=4)

        # Replace the old file only after successful write
        os.replace(temp_path, filepath)

    except Exception as e:
        print(f"[Database] ERROR during safe write: {e}")


def load_database() -> dict:
    """
    Loads the database file if it exists.
    If missing or corrupted, returns an empty structure.
    """
    if not os.path.exists(DB_FILE):
        return {"runs": []}

    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        print("[Database] WARNING: Database corrupted. Resetting.")
        return {"runs": []}


def save_run_summary(summary: dict) -> None:
    """
    Saves a single training run summary to the database.
    Adds a timestamp and validates fields.
    """
    db = load_database()

    # Add timestamp
    summary["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Validate expected fields
    required = ["episodes_ran", "avg_reward_window", "stopped_early"]
    for key in required:
        if key not in summary:
            print(f"[Database] WARNING: Missing field '{key}' in summary.")

    db["runs"].append(summary)
    _safe_write(DB_FILE, db)
    print(f"[Database] Run summary saved. Total stored runs: {len(db['runs'])}")


def get_recent_runs(limit: int = 5) -> list[dict]:
    """
    Returns the most recent training runs.
    """
    db = load_database()
    return db["runs"][-limit:]
