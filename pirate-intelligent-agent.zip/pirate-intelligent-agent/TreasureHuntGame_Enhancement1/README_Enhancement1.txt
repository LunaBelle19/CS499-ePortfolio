Enhancement One – Software Design and Engineering
Artifact: TreasureHuntGame (Reinforcement Learning Project)

Summary:
This enhancement refactors the original TreasureHuntGame into a modular,
object-oriented design. The new version includes separate files for the
agent, environment, and game controller. This structure improves
organization, testing, and scalability.

Changes Made:
- Created modular files for clear structure
- Added reusable Agent, Environment, and GameController classes
- Implemented parameter validation and error handling
- Enhanced readability and maintainability

Outcome:
The enhanced project demonstrates improved architecture, reusability,
and professional-level software design aligned with CS-499 outcomes.

To Run:
1. Open Terminal in Visual Studio Code
2. Type: python main.py
3. Observe the training progress in the terminal
