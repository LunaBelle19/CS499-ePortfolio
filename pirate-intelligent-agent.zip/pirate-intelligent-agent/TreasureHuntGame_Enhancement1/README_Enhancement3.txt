Enhancement Three – Databases

Artifact: TreasureHuntGame (Reinforcement Learning Project)

Summary:
This enhancement adds a lightweight, file-based database to the TreasureHuntGame. A new module, database_handler.py, saves training summaries, metrics, and run history to a JSON database. 
This gives the project persistent storage, improved data reliability, and better support for analyzing multiple training runs.

Changes Made:

Added database_handler.py to manage JSON-based data storage

Implemented safe, atomic write operations to prevent file corruption

Added timestamped logging for each training run

Updated game_controller.py to automatically save a run summary

Added data validation and error handling for secure operations

Outcome:
This enhancement demonstrates database design, secure data handling, and integration of persistent storage. 
It aligns with CS-499 outcomes by showing strong software engineering practices, a security mindset, and the ability to manage structured data.

To Run:

Open the project folder in Visual Studio Code

Open the terminal

Type: python main.py

After training completes, view saved results in training_database.json