import numpy as np
import random

class Agent:
    """Q-learning agent with epsilon/alpha decay, reproducibility, and constant-time lookups."""

    def __init__(
        self,
        state_size: int,
        action_size: int = 2,
        alpha_start: float = 0.3,
        alpha_min: float = 0.05,
        alpha_decay: float = 0.995,
        gamma: float = 0.90,
        epsilon_start: float = 1.0,
        epsilon_min: float = 0.05,
        epsilon_decay: float = 0.995,
        seed: int | None = 42,
    ) -> None:
        # ---- Validation ----
        if state_size <= 1:
            raise ValueError("state_size must be > 1")
        if action_size <= 0:
            raise ValueError("action_size must be > 0")
        for name, val in [
            ("alpha_start", alpha_start),
            ("alpha_min", alpha_min),
            ("gamma", gamma),
            ("epsilon_start", epsilon_start),
            ("epsilon_min", epsilon_min),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"{name} must be in [0.0, 1.0]")
        if not (0.0 < alpha_decay <= 1.0):
            raise ValueError("alpha_decay must be in (0.0, 1.0]")
        if not (0.0 < epsilon_decay <= 1.0):
            raise ValueError("epsilon_decay must be in (0.0, 1.0]")

        # ---- RNG for reproducibility ----
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        self.state_size = state_size
        self.action_size = action_size
        self.alpha = alpha_start
        self.alpha_min = alpha_min
        self.alpha_decay = alpha_decay
        self.gamma = gamma
        self.epsilon = epsilon_start
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay

        # Q-table: shape [S, A], initialized to zeros (O(S*A) space)
        self.q_table = np.zeros((state_size, action_size), dtype=np.float32)

    # ---- Policy ----
    def choose_action(self, state: int) -> int:
        """ε-greedy policy with constant-time lookups."""
        if random.random() < self.epsilon:
            return random.randint(0, self.action_size - 1)
        # np.argmax is vectorized and runs in O(A)
        return int(np.argmax(self.q_table[state]))

    # ---- Learning ----
    def update_q(self, state: int, action: int, reward: float, next_state: int) -> None:
        """Standard Q-learning update (O(1) per step)."""
        best_next = float(np.max(self.q_table[next_state]))
        td_target = reward + self.gamma * best_next
        td_error = td_target - self.q_table[state, action]
        self.q_table[state, action] += self.alpha * td_error

    # ---- Schedules ----
    def end_episode(self) -> None:
        """Exponential decay schedules for ε and α after each episode."""
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        self.alpha = max(self.alpha_min, self.alpha * self.alpha_decay)
