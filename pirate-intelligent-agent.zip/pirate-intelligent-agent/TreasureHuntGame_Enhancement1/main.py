from game_controller import GameController
import time

def _progress(ep: int, metric: float) -> None:
    print(f"[Episode {ep:>4}] metric={metric:.3f}")

if __name__ == "__main__":
    game = GameController(
        episodes=2000,
        max_steps_per_episode=100,
        moving_avg_window=100,
        target_avg_reward=7.0,
        env_size=7,
        seed=42,
    )
    result = game.train(progress_cb=_progress)
    print("Training summary:", result)

    # Watch one greedy run (no exploration)
    path = game.run_greedy_episode()
    print("\nGreedy demo path (states):", path)

    # Simple ASCII replay of the path
    print("\nReplay:")
    size = game.env.size
    treasure = game.env.treasure
    for s in path:
        row = ["_"] * size
        row[treasure] = "T"  # Treasure marker
        row[s] = "A"        # Agent marker
        print(" ".join(row))
        time.sleep(0.15)

    print("\nTreasureHuntGame enhancement (Algorithms & Data Structure) finished successfully.")

